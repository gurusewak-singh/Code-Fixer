function isPalindrome(str) {
    str = str.toLowerCase();
    let j = str.length - 1;
    for (let i = 0; i < str.length / 2; i++) {
        if (str[i] !== str[j]) {
            return false;
        }
        j--;
    }
    return true;
}

let str1 = "racecar";
let str2 = "nitin";
let str3 = "Rama";
let str4 = "madam";
let str5 = "A man, a plan, a canal: Panama";

console.log(isPalindrome(str1)); // true
console.log(isPalindrome(str2)); // true
console.log(isPalindrome(str3)); // false
console.log(isPalindrome(str4)); // true
console.log(isPalindrome(str5.toLowerCase().replace(/[^a-zA-Z0-9]/g, ""))); //true