function fibonacci(num) {
    if (num <= 0) return 0;
    if (num === 1) return 1;
    let a = 0, b = 1, temp;
    for (let i = 2; i <= num; i++) {
        temp = a + b;
        a = b;
        b = temp;
    }
    return b;
}

console.log("Fibonacci(5): " + fibonacci(5));
console.log("Fibonacci(8): " + fibonacci(8));
console.log("Fibonacci(0): " + fibonacci(0));
console.log("Fibonacci(-1): " + fibonacci(-1));