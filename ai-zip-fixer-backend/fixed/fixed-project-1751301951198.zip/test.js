function isArmstrong(num) {
  const numStr = num.toString();
  const numDigits = numStr.length;
  let sum = 0;

  for (let i = 0; i < numDigits; i++) {
    const digit = parseInt(numStr[i]);
    sum += Math.pow(digit, numDigits);
  }

  return sum === num;
}

// Test cases
console.log("153 is Armstrong: " + isArmstrong(153));  // true
console.log("1634 is Armstrong: " + isArmstrong(1634)); // true
console.log("123 is Armstrong: " + isArmstrong(123));   // false
console.log("0 is Armstrong: " + isArmstrong(0));     // true
console.log("1 is Armstrong: " + isArmstrong(1));     //true